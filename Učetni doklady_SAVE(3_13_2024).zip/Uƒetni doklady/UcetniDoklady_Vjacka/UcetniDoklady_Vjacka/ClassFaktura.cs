﻿using System;
using System.Collections.ObjectModel;

namespace UcetniDoklady_Vjacka
{
    public class ClassFaktura:IUcetniDoklad
    {
        ushort cislo;
        char druh;
        DateTime datumVystaveni;
        DateTime datumSplatnosti;
        double castka;
        ClassPlatba platba;

        public ObservableCollection<ClassPolozka> PolozkyFaktury { get; set; } = new ObservableCollection<ClassPolozka>();
        public ushort Cislo { get { return cislo; } set { if (value >= 0) { cislo = value; } } }
        public double Castka { get { return castka; } set { if (value >= 0) { castka = value; } } }
        public char Druh { get { return druh; } set { if (value == 'V' || value == 'P') { castka = value; } } }
        public DateTime DatumVystaveni { get { return datumVystaveni; } set { if (value != null) { datumVystaveni = value; } } }
        public DateTime DatumSplatnosti { get { return datumSplatnosti; } set { if (value != null) { datumSplatnosti = value; } } }
        public ClassPlatba Platba { get { return platba; } set { if (value != null) { platba = value; } } }

        public ClassFaktura()
        {
            
        }
        public override string ToString()
        {
            if(NovFakturaWindow.getInstance().prijemRadioButton.IsChecked == true) 
            {
                return Cislo + " (P)" + "\t" + Castka + " Kč";
            }
            else if(NovFakturaWindow.getInstance().vydejRadioButton.IsChecked == true)
            {
                return Cislo + " (V)" + "\t" + Castka + " Kč";
            }
            return null;
        }
    }
}
