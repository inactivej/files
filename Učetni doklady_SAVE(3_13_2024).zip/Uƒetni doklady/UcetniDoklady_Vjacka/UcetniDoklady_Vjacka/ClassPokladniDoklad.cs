﻿using System;

namespace UcetniDoklady_Vjacka
{
    public class ClassPokladniDoklad:IUcetniDoklad
    {
        ushort cislo;
        char druh;
        DateTime datumVystaveni;        
        double castka;
        public ushort Cislo { get { return cislo; } set { if (value >= 0) { cislo = value; } } }
        public double Castka { get { return castka; } set { if (value >= 0) { castka = value; } } }
        public char Druh { get { return druh; } set { if (value == 'V' || value == 'P') { castka = value; } } }
        public DateTime DatumVystaveni { get { return datumVystaveni; } set { if (value != null) { datumVystaveni = value; } } }
        public ClassPokladniDoklad()
        {
            
        }
        public override string ToString()
        {
            return Cislo + "\t" + Castka + " Kč";
        }
    }
}
