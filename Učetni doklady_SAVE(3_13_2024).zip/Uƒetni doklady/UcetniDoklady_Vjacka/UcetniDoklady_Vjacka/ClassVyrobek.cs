﻿namespace UcetniDoklady_Vjacka
{
    public class ClassVyrobek
    {
        string kod,nazev;
        double cenaBezDPH,sazbaDPH;
        public string Kod { get { return kod; } set { if(!string.IsNullOrEmpty(value)) { kod = value; } } } 
        public string Nazev { get { return nazev; } set { if(!string.IsNullOrEmpty(value)) { nazev = value; } } } 
        public double CenaBezDPH { get { return cenaBezDPH; } set { if(value >= 0) { cenaBezDPH = value; } } } 
        public double SazbaDPH { get { return sazbaDPH; } set { if(value == 12 || value == 21) { sazbaDPH = value; } } }
        public ClassVyrobek()
        {
            
        }
        public override string ToString()
        {
            return Kod + "\t" + Nazev;   
        }
    }
}
