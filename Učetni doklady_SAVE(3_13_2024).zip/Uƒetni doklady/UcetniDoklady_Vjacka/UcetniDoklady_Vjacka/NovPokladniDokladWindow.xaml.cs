﻿using System.Windows;

namespace UcetniDoklady_Vjacka
{
    /// <summary>
    /// Interaction logic for NovPokladniDokladWindow.xaml
    /// </summary>
    public partial class NovPokladniDokladWindow : Window
    {
        ClassPokladniDoklad pokladniDoklad;
        public NovPokladniDokladWindow(ClassPokladniDoklad pokladniDoklad)
        {
            InitializeComponent();
            this.pokladniDoklad = pokladniDoklad;
        }
    }
}
