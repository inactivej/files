﻿using System;
using System.Collections.ObjectModel;
using System.Net;
using System.Windows;

namespace UcetniDoklady_Vjacka
{
    /// <summary>
    /// Interaction logic for NovFakturaWindow.xaml
    /// </summary>
    public partial class NovFakturaWindow : Window
    {
        ClassFaktura faktura;
        public ObservableCollection<ClassPolozka> PolozkyFaktury { get; set; } = new ObservableCollection<ClassPolozka>();
        static NovFakturaWindow instance;
        public NovFakturaWindow(ClassFaktura faktura)
        {
            InitializeComponent();
            if(faktura != null)
            {
                this.faktura = faktura;
                faktura.PolozkyFaktury = PolozkyFaktury;
                instance = this;
            }
        }
        public static NovFakturaWindow getInstance() { return instance; }

        private void stornoButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void ulozitButton_Click(object sender, RoutedEventArgs e)
        {
            ushort cisloDokladu;
            if (!ushort.TryParse(cisloTextBox.Text, out cisloDokladu))
            {
                MessageBox.Show("Číslo dokladu musí být celé číslo", "Chybný vstup uživatele", MessageBoxButton.OK, MessageBoxImage.Stop);
                cisloTextBox.Text = string.Empty;
            }
            else
            {
                if(prijemRadioButton.IsChecked == false && vydejRadioButton.IsChecked == false)
                {
                    MessageBox.Show("Vyberte typ faktury", "Chybný vstup uživatele", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else
                {
                    if(datumVystaveniDatePicker.SelectedDate == null && datumSplatnostiDatePicker.SelectedDate == null)
                    {
                        MessageBox.Show("Uveďte data vystavení a splatnosti na faktuře", "Chybný vstup uživatele", MessageBoxButton.OK, MessageBoxImage.Stop);
                    }
                    else if(datumVystaveniDatePicker.SelectedDate > datumSplatnostiDatePicker.SelectedDate)
                    {
                        MessageBox.Show("Chybná data vystavení a splatnosti. Zkontrolujte správnost na faktuře!", "Chybný vstup uživatele", MessageBoxButton.OK, MessageBoxImage.Stop);
                    }
                    else
                    {
                        if (PolozkyFaktury.Count == 0)
                        {
                            var result = MessageBox.Show("Vážně si přejete uložit fakturu bez položek?", "Dotaz", MessageBoxButton.YesNo, MessageBoxImage.Question);
                            if (result == MessageBoxResult.Yes)
                            {
                                faktura.Cislo = cisloDokladu;                              
                                faktura.DatumVystaveni = (DateTime)datumVystaveniDatePicker.SelectedDate;
                                faktura.DatumSplatnosti = (DateTime)datumSplatnostiDatePicker.SelectedDate;
                                DialogResult = true;
                                Close();
                            }
                        }
                        else
                        {
                            //dodelat
                        }
                    }
                }
            }
        }       
    }
}
