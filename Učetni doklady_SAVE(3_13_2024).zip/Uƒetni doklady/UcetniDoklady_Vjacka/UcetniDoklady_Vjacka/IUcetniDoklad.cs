﻿using System;

namespace UcetniDoklady_Vjacka
{
    public interface IUcetniDoklad
    {
        ushort Cislo { get; set; }
        char Druh { get; set; }
        DateTime DatumVystaveni { get; set; }   
        double Castka { get; set; } 

    }
}
