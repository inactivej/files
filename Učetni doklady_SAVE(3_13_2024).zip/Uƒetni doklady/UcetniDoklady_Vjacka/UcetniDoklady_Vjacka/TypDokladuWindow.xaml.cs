﻿using System;
using System.Windows;

namespace UcetniDoklady_Vjacka
{
    /// <summary>
    /// Interaction logic for TypDokladuWindow.xaml
    /// </summary>
    public partial class TypDokladuWindow : Window
    {
        public IUcetniDoklad SelectedType { get; set; }
        static TypDokladuWindow instance;
        public TypDokladuWindow()
        {
            InitializeComponent();
            instance = this;
        }
        public static TypDokladuWindow getInstance() { return instance; }

        private void exitRB_Checked(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void novPDRB_Checked(object sender, RoutedEventArgs e)
        {
            SelectedType = new ClassPokladniDoklad();
            DialogResult = true;
            Close();
        }

        private void novFavRB_Checked(object sender, RoutedEventArgs e)
        {
            SelectedType = new ClassFaktura();
            DialogResult = true;
            Close();
        }
    }
}
