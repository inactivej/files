﻿namespace UcetniDoklady_Vjacka
{
    public class ClassPlatba
    {
        string typ,ucet;
        public string Typ { get { return typ; } set { if (!string.IsNullOrEmpty(value)) { typ = value; } } }
        public string Ucet { get { return ucet; } set { if (!string.IsNullOrEmpty(value)) { ucet = value; } } }
        public ClassPlatba()
        {
            
        }
        public override string ToString()
        {
            return Ucet + $" ({Typ})";
        }
    }
}
