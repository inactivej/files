﻿using System.Collections.ObjectModel;
using System.Windows;

namespace UcetniDoklady_Vjacka
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public ObservableCollection<IUcetniDoklad> UcetniDoklady { get; set; } = new ObservableCollection<IUcetniDoklad>();
        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;
        }

        private void novyDokladItem_Click(object sender, RoutedEventArgs e)
        {
            TypDokladuWindow window = new TypDokladuWindow();
            window.ShowDialog();
            if (window.DialogResult == true)
            {
                if (TypDokladuWindow.getInstance().SelectedType is ClassFaktura)
                {
                    ClassFaktura faktura = new ClassFaktura();
                    NovFakturaWindow nfWindow = new NovFakturaWindow(faktura);
                    nfWindow.ShowDialog();
                    if (nfWindow.DialogResult == true)
                    {
                        UcetniDoklady.Add(faktura);
                    }
                }
                else if (TypDokladuWindow.getInstance().SelectedType is ClassPokladniDoklad)
                {
                    ClassPokladniDoklad pokladniDoklad = new ClassPokladniDoklad();
                    NovPokladniDokladWindow pdWindow = new NovPokladniDokladWindow(pokladniDoklad);
                    pdWindow.ShowDialog();
                    if (pdWindow.DialogResult == true)
                    {
                        UcetniDoklady.Add(pokladniDoklad);
                    }
                }
            }
        }

        private void seznamDokladuListBox_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if(seznamDokladuListBox.SelectedItem is ClassFaktura)
            {
                ClassFaktura vf = seznamDokladuListBox.SelectedItem as ClassFaktura;
                NovFakturaWindow nfWindow = new NovFakturaWindow(vf);
                nfWindow.ShowDialog();                
            }
            else
            {
                ClassPokladniDoklad pd = seznamDokladuListBox.SelectedItem as ClassPokladniDoklad;
                NovPokladniDokladWindow pdWindow = new NovPokladniDokladWindow(pd);
                pdWindow.ShowDialog();                
            }
            seznamDokladuListBox.Items.Refresh();
        }
    }
}
