﻿namespace UcetniDoklady_Vjacka
{
    public class ClassPolozka
    {
        ushort pocetKs;
        double sazbaDPH;
        ClassVyrobek vyrobek;
        public double SazbaDPH { get { return sazbaDPH; } set { if (value == 12 || value == 21) { sazbaDPH = value; } } }
        public ushort PocetKs { get { return pocetKs; } set { if (value == 12 || value == 21) { pocetKs = value; } } }
        public ClassVyrobek Vyrobek { get { return vyrobek; } set { if (value != null) { vyrobek = value; } } }
        public ClassPolozka()
        {
            
        }
        public override string ToString()
        {
            return Vyrobek.Kod + ";"+Vyrobek.Nazev+"\t" + SazbaDPH+"%";    
        }

    }
}
