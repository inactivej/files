﻿/*
using System;
using System.Windows;

namespace Project
{
    /// <summary>
    /// Interaction logic for ProductTypeWindow.xaml
    /// </summary>
    public partial class ProductTypeWindow : Window
    {
        static ProductTypeWindow instance;
        public ProductWindow window;

        public ProductTypeWindow()
        {
            InitializeComponent();
            instance = this;
        }

        public static ProductTypeWindow getInstance() { return instance; }

        private void MPCB_Checked(object sender, RoutedEventArgs e)
        {
            this.Close();
            window = new ProductWindow(new ClassMusicProject());
            window.Show();
        }

        private void exitCB_Checked(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void INSTRCB_Checked(object sender, RoutedEventArgs e)
        {
            this.Close();
            window = new ProductWindow(new ClassInstrument());
            window.Show();
        }
    }
}
*/
using System;
using System.ComponentModel;
using System.Windows;

namespace Project
{
    public partial class ProductTypeWindow : Window
    {
        private static ProductTypeWindow instance;
        public IProduct SelectedProduct { get; set; }

        public ProductTypeWindow()
        {
            InitializeComponent();
            instance = this;
        }

        public static ProductTypeWindow getInstance() { return instance; }

        private void MPCB_Checked(object sender, RoutedEventArgs e)
        {
            SelectedProduct = new ClassMusicProject();
            this.DialogResult = true;
            this.Close();
        }

        private void exitCB_Checked(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void INSTRCB_Checked(object sender, RoutedEventArgs e)
        {
            SelectedProduct = new ClassInstrument();
            this.DialogResult = true;
            this.Close();
        }
    }
}

