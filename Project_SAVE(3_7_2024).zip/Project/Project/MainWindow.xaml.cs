﻿using System.Collections.ObjectModel;
using System.Windows;


namespace Project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ClassShop Shop { get; set; }        
        public ObservableCollection<ClassShopPart> ShopParts { get; set; } = new ObservableCollection<ClassShopPart>();
        public MainWindow()
        {
            InitializeComponent(); 
            if (ShopParts.Count != 0)
            {
                ShopParts = Shop.ShopParts;
                
            }
            shopPartsListBox.Visibility = Visibility.Hidden;
            removeShopPartButton.Visibility = Visibility.Hidden;
            DataContext = this;
        }
        private void createShopButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(shopTextBox.Text))
            {
                MessageBox.Show("Shop name is necessary for creating new one\nPlease enter name!", "Empty input value for Shop", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            else
            {
                Shop = new ClassShop();
                shopPartsListBox.Visibility = Visibility.Visible;
                removeShopPartButton.Visibility = Visibility.Visible;
                MessageBox.Show("Shop was created!", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void newShopPartItem_Click(object sender, RoutedEventArgs e)
        {
            ClassShopPart shopPart = new ClassShopPart();
            ShopPartWindow window = new ShopPartWindow(shopPart);
            window.ShowDialog();
            if (window.DialogResult == true)
            {
                ShopParts.Add(shopPart);
            }
        }

        private void shopPartsListBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            ClassShopPart selectedItem = shopPartsListBox.SelectedItem as ClassShopPart;
            ShopPartWindow window = new ShopPartWindow(selectedItem);
            window.ShowDialog();            
            shopPartsListBox.Items.Refresh();
        }       
    }
}
