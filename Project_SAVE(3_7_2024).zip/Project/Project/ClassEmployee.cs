﻿using System;
using System.Reflection;
using System.Runtime.Serialization.Formatters;
using System.Security.Policy;

namespace Project
{
    public class ClassEmployee : IPerson
    {
        ushort id;
        string name, surname, type;
        DateTime dob;
        private static ushort count = 0;
        public ushort ID { get { return id; } set { if (value >= 0) { id = value; } } }
        public string Name { get { return name; } set { if (!string.IsNullOrEmpty(value)) { name = value; } } }
        public string Surname { get { return surname; } set { if (!string.IsNullOrEmpty(value)) { surname = value; } } }
        public string Fullname { get { return Name + " " + Surname; } }        
        public bool FullTime { get; set; }
        public DateTime DOB { get { return dob; } set { dob = value; } }
        public bool IsLeader { get; set; }
        public ushort getID()
        {
            return ID;
        }
        public ClassEmployee()
        {
            this.ID = ++count;
        }
        public override string ToString()
        {
            if (FullTime == true)
            {
                if (!IsLeader)
                {
                    return Fullname + "\t" + "(F)";
                }
                else
                {
                    return Fullname + "\t" + "(F)(*L*)";
                }                
            }
            else if(FullTime == false)
            {
                return Fullname + "\t" + "(P)";
            }
            return null;
        }
    }
}

