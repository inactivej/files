﻿using System;
using System.Collections.ObjectModel;

namespace Project
{
    public class ClassMusicProject : IProduct
    {
        public ObservableCollection<ClassMusician> SongsWriters { get; set; } = new ObservableCollection<ClassMusician>();
        string name;
        ushort price, id;
        DateTime releasedate;
        public ushort ID { get { return id; } set { if (value >= 0) { id = value; } } }
        public string Name { get { return name; } set { if (!string.IsNullOrEmpty(value)) { name = value; } } }
        public ushort Price { get { return price; } set { if (value >= 0) { price = value; } } }
        public ClassMusician Songwriter { get; set; }
        public DateTime ReleaseDate { get { return releasedate; } set { if (value != null) { releasedate = value; } } }
        public ClassMusicProject()
        {

        }
        public override string ToString()
        {
            return $"{ID}|{Name} - Song Writer:{Songwriter}({Price} Kč)";
        }
    }
}
