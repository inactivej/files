﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace Project
{
    /// <summary>
    /// Interaction logic for EmployeeWindow.xaml
    /// </summary>
    public partial class EmployeeWindow : Window
    {
        ClassEmployee employee;
        //ClassEmployee employee_copy = new ClassEmployee();
        public EmployeeWindow(ClassEmployee employee)
        {
            InitializeComponent();
            this.employee = employee;            
            DataContext = this.employee;
        }
        private void okBTN_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(E_NameTextBox.Text) || string.IsNullOrEmpty(E_SurnameTextBox.Text))
            {
                MessageBox.Show("Enter Full name of employee", "Invalid input", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            else
            {
                if (typeComboBox.SelectedItem == null)
                {
                    MessageBox.Show("Select employee's work type", "Invalid input", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else
                {
                    if (dobDatePicker.SelectedDate == null || dobDatePicker.SelectedDate > System.DateTime.Now)
                    {
                        MessageBox.Show("Invalid Date of birth", "Invalid input", MessageBoxButton.OK, MessageBoxImage.Stop);
                    }
                    else
                    {
                        employee.ID = employee.getID();
                        employee.Name = E_NameTextBox.Text;
                        employee.Surname = E_SurnameTextBox.Text;                                           
                        if (string.Equals((typeComboBox.SelectedItem as ComboBoxItem)?.Content.ToString(), "Full-time", StringComparison.OrdinalIgnoreCase))
                        {
                            employee.FullTime = true;
                        }
                        else
                        {
                            employee.FullTime = false;
                        }
                        DialogResult = true;
                    }
                }
            }
        }
        private void stornoBTN_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
