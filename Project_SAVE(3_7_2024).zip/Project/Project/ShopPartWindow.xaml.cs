﻿using System;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;

namespace Project
{
    /// <summary>
    /// Interaction logic for ShopPartWindow.xaml
    /// </summary>
    public partial class ShopPartWindow : Window
    {
        static ShopPartWindow instance;
        MainWindow MainWindow { get; set; } = App.Current.MainWindow as MainWindow;
        public void File()
        {
            StreamReader reader = new StreamReader("musicians.txt");
            while (!reader.EndOfStream)
            {
                string line = reader.ReadLine();
                string[] values = line.Split(';');
                Musicians.Add(new ClassMusician(values[0], values[1], values[2], values[3], DateTime.Parse(values[4])));
            }
            reader.Close();
        }
        ClassShopPart shopPart;

        //Jak ti ze souboru, tak ti nově vytvoření (okno dodělat!!!)
        public ObservableCollection<ClassMusician> Musicians { get; set; } = new ObservableCollection<ClassMusician>();

        public ObservableCollection<ClassEmployee> Employees { get; set; } = new ObservableCollection<ClassEmployee>();
        public ObservableCollection<IProduct> Stock { get; set; } = new ObservableCollection<IProduct>();
        string partname = string.Empty;
        /*--------------------------------------------------------------------------------------------------------------*/
        public ShopPartWindow(ClassShopPart shopPart)
        {
            InitializeComponent();
            File();
            instance = this;
            partNameTextBox.Text = shopPart.PartName;
            if (Employees.Count != 0)
            {
                leaderComboBox.SelectedItem = shopPart.Leader.ToString();
            }
            shopPart_ItemsStock.Visibility = Visibility.Hidden;
            shopPartEmployeesListBox.Visibility = Visibility.Hidden;
            removeButton.Visibility = Visibility.Hidden;
            this.shopPart = shopPart;
            DataContext = this.shopPart;
            Employees = shopPart.Employees;
            Stock = shopPart.Stock;
            ShopPartInfoLabel.Content = MainWindow.shopTextBox.Text + "-" + partname;
        }
        public static ShopPartWindow getInstance() { return instance; }
        private void newEmployeeItem_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Add new employee?", "Employee menu", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                ClassEmployee employee = new ClassEmployee();
                EmployeeWindow window = new EmployeeWindow(employee);
                window.ShowDialog();
                if (window.DialogResult == true)
                {
                    shopPart.EmployeeCount++;
                    Employees.Add(employee);
                }
            }
        }
        private void okBTN_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(partNameTextBox.Text))
            {
                MessageBox.Show("Enter part name", "Invalid input", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {

                if (shopPart.EmployeeCount == 0)
                {
                    MessageBox.Show($"Shop part must have a leader\nActual count of employees is {shopPart.EmployeeCount} (Please add employes to able to finish)", "Attention", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else if (leaderComboBox.SelectedItem == null)
                {
                    MessageBox.Show($"Shop part must have a leader\nActual count of employees is {shopPart.EmployeeCount} (Select one from list of employees)", "Empty selection", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else if (leaderComboBox.SelectedItem.ToString().Contains("(P)"))
                {
                    MessageBox.Show($"Shop leader must work Full Time {"(F)"}", "Attention", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else
                {
                    shopPart.PartName = partNameTextBox.Text;
                    shopPart.Leader = (ClassEmployee)leaderComboBox.SelectedItem;
                    foreach (ClassEmployee employee in Employees)
                    {
                        if (employee == shopPart.Leader)
                        {
                            employee.IsLeader = true;
                        }
                    }
                    DialogResult = true;
                    this.Close();
                }

            }
        }
        private void showEmployeesCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            shopPartEmployeesListBox.Visibility = Visibility.Visible;
            removeButton.Visibility = Visibility.Visible;
        }

        private void showStockCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            shopPart_ItemsStock.Visibility = Visibility.Visible;
            removeButton.Visibility = Visibility.Visible;
        }

        private void showEmployeesCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            shopPartEmployeesListBox.Visibility = Visibility.Hidden;
            if (showStockCheckBox.IsChecked == false)
            {
                removeButton.Visibility = Visibility.Hidden;
            }
        }

        private void showStockCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            shopPart_ItemsStock.Visibility = Visibility.Hidden;
            if (showEmployeesCheckBox.IsChecked == false)
            {
                removeButton.Visibility = Visibility.Hidden;
            }
        }

        private void newItem_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Add new product?", "Stock", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                ProductTypeWindow productTypeWindow = new ProductTypeWindow();
                productTypeWindow.ShowDialog();
                if (productTypeWindow.DialogResult == true)
                {
                    ProductWindow productWindow = new ProductWindow(productTypeWindow.SelectedProduct);
                    productWindow.ShowDialog();
                    if (productWindow.DialogResult == true)
                    {
                        shopPart.Stock.Add(productTypeWindow.SelectedProduct);
                    }
                }
            }

        }
    }
}
