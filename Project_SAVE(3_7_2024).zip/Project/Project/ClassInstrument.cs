﻿namespace Project
{
    public class ClassInstrument:IProduct
    {
        string name, description, publischer;
        ushort price, id;
        bool stringTypeInstument;
        public ushort ID { get { return id; } set { if (value >= 0) { id = value; } } }
        public string Name { get { return name; } set { if (!string.IsNullOrEmpty(value)) { name = value; } } }
        public ushort Price { get { return price; } set { if (value >= 0) { price = value; } } }
        public bool StringTypeInstrument { get { return stringTypeInstument; } set { stringTypeInstument = value; } }
        public ClassInstrument()
        {

        }
        public override string ToString()
        {
            if (StringTypeInstrument)
            {
                return $"{ID}|{Price} Kč|String: Yes";
            }
            else
            {
                return $"{ID}|{Price} Kč|String: No";
            }
        }
    }
}
