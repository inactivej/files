﻿namespace Project
{
    public interface IProduct
    {
        ushort ID { get; set; }
        string Name { get; set; }
        ushort Price { get; set; }
    }
}
