﻿using System;

namespace Project
{
    public class ClassMusician : IPerson
    {
        string name;
        string surname;
        string type;
        DateTime dob;
        string stageName;
        public string Name { get { return name; } set { if (!string.IsNullOrEmpty(value)) { name = value; } } }
        public string Surname { get { return surname; } set { if (!string.IsNullOrEmpty(value)) { surname = value; } } }
        public string Fullname { get { return Name + " " + Surname; } }
        public string StageName { get { return stageName; } set { if (!string.IsNullOrEmpty(value)) { stageName = value; } } }
        public string Type { get { return type; } set { if (!string.IsNullOrEmpty(value)) { type = value; } } }
        public DateTime DOB { get { return dob; } set { dob = value; } }
        public ClassMusician(string name, string surname, string stageName,string type,DateTime dob)
        {
            Name = name;
            Surname = surname;
            StageName = stageName;
            Type = type;
            DOB = dob;
        }        
        public override string ToString()
        {
            return $"{StageName}-({Type})";
        }
    }
}
