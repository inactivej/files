﻿using System;
using System.Windows;

namespace Project
{
    /// <summary>
    /// Interaction logic for ProductWindow.xaml
    /// </summary>
    public partial class ProductWindow : Window
    {
        IProduct product = ProductTypeWindow.getInstance().SelectedProduct;
        public ProductWindow(IProduct product)
        {
            InitializeComponent();
            this.product = product;
            if (product is ClassMusicProject)
            {
                DisplayComponents_MusicProject();
            }
            else if (product is ClassInstrument)
            {
                DisplayComponents_Instrumental();
            }
        }
        void DisplayComponents_MusicProject()
        {
            checkbox_StringInstro.Visibility = Visibility.Hidden;

            datePickerDOR.Visibility = Visibility.Visible;
            label_DOR.Visibility = Visibility.Visible;
            label_DOR.Content = "DOR";
            label_songWriter.Visibility = Visibility.Visible;
            label_songWriter.Content = "Singer";
            songWriterComboBox.Visibility = Visibility.Visible;
            songWriterComboBox.ItemsSource = ShopPartWindow.getInstance().Musicians;
        }

        void DisplayComponents_Instrumental()
        {
            songWriterComboBox.Visibility = Visibility.Hidden;
            label_songWriter.Visibility = Visibility.Hidden;
            datePickerDOR.Visibility = Visibility.Hidden;

            checkbox_StringInstro.Visibility = Visibility.Visible;
            checkbox_StringInstro.Content = "String instrument";
        }

        private void okBTN_Click_1(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(NameTextBox.Text))
            {
                MessageBox.Show("Enter Full name of project", "Invalid input", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            else
            {
                ushort price;
                if (!ushort.TryParse(priceTxtBox.Text, out price))
                {
                    MessageBox.Show("Enter valid price", "Invalid input", MessageBoxButton.OK, MessageBoxImage.Stop);
                    priceTxtBox.Text = string.Empty;
                }
                else
                {
                    product.Name = NameTextBox.Text;
                    product.Price = ushort.Parse(priceTxtBox.Text);
                    if (product is ClassMusicProject)
                    {
                        if (datePickerDOR.SelectedDate == null)
                        {
                            MessageBox.Show("Select date of release", "Empty selection", MessageBoxButton.OK, MessageBoxImage.Stop);
                        }
                        else
                        {
                            if (songWriterComboBox.SelectedItem == null)
                            {
                                MessageBox.Show("Select musician", "Empty selection", MessageBoxButton.OK, MessageBoxImage.Stop);
                            }
                            else
                            {
                                ClassMusicProject mp = (ClassMusicProject)product;
                                mp.ReleaseDate = (DateTime)datePickerDOR.SelectedDate;
                                mp.Songwriter = (ClassMusician)songWriterComboBox.SelectedItem;
                                DialogResult = true;
                                this.Close();
                            }
                        }
                    }
                    else if (product is ClassInstrument)
                    {
                        ClassInstrument instrument = (ClassInstrument)product;
                        instrument.StringTypeInstrument = (bool)checkbox_StringInstro.IsChecked;
                        DialogResult = true;
                        this.Close();
                    }
                }                
            }
        }
        private void stornoBTN_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

    }
}


