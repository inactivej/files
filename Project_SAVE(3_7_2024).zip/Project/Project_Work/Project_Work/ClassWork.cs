﻿using System.Collections.ObjectModel;

namespace Project_Work
{
    public class ClassWork
    {
        string ico;
        string name;
        public string ICO { get { return ico; } set { if (!string.IsNullOrEmpty(value)) { ico = value; } } }
        public string Name { get { return name; } set { if (!string.IsNullOrEmpty(value)) { name = value; } } }
        public ObservableCollection<ClassSector> Sectors { get; set; } = new ObservableCollection<ClassSector>();   
        public ObservableCollection<ClassSupplier> Suppliers { get; set; } = new ObservableCollection<ClassSupplier>();   
        public ClassWork()
        {

        }
        public override string ToString()
        {
            return Name + ": " + ICO;
        }

    }
}
