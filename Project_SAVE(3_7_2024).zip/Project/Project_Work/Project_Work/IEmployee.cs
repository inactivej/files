﻿using System;

namespace Project_Work
{
    public interface IEmployee
    {
        string Name { get; set; }
        string Surname { get; set; }
        string FullName { get; }
        ushort ID { get; set; }
        DateTime StartOfWork { get; set; }
        ClassSector Sector { get; set; }
        bool IndefinitePeriod { get; set; }
    }
}
