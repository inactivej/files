﻿using System.Data;
using System.Windows;

namespace Project_Work
{
    public class ClassSupplier
    {
        ushort id;
        string name;
        bool favorite;

        public ushort ID { get { return id; } set { id = value; } }
        public string Name { get { return name; } set { if (!string.IsNullOrEmpty(value)) { name = value; } } }
        public bool Favorite { get { return favorite; } set { favorite = value; } }
        public ClassSupplier()
        {
            
        }
        public override string ToString()
        {
            if(Favorite == true)
            {
                return  $"* ({ID}): " +Name;
            }
            else if(favorite == false)
            {
                return $"({ID}): " + Name;
            }
            return null;
        }

        public override bool Equals(object obj)
        {
            return obj is ClassSupplier supplier &&
                   ID == supplier.ID;
        }

        public override int GetHashCode()
        {
            return 1213502048 + ID.GetHashCode();
        }
    }
}
