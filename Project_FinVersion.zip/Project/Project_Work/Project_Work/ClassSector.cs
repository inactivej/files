﻿using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace Project_Work
{
    public class ClassSector
    {
        string name;
        ushort employeesCount;      
        public string Name { get { return name; } set { if (!string.IsNullOrEmpty(value)) { name = value; } } }
        public ObservableCollection<IEmployee> Employees { get; set; } = new ObservableCollection<IEmployee>();
        public ushort EmployeesCount { get { return  employeesCount;} set { if (value != 0) { employeesCount = value; } } }      
        public ClassSector()
        {
            
        }
        public override string ToString()
        {
            return Name;
        }
        public override bool Equals(object obj)
        {
            return obj is ClassSector sector &&
                   Name == sector.Name;
        }

        public override int GetHashCode()
        {
            return 539060726 + EqualityComparer<string>.Default.GetHashCode(Name);
        }
    }
}
