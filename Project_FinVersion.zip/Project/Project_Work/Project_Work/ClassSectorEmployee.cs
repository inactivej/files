﻿using System;

namespace Project_Work
{
    public class ClassSectorEmployee : IEmployee
    {
        string name;
        string surname;
        ushort id;
        DateTime startOfWork;
        ClassSector sector;
        ClassSectorLeader leader;
        bool indefinitePeriod;
        public string Name { get { return name; } set { if (!string.IsNullOrEmpty(value)) { name = value; } } }
        public string Surname { get { return surname; } set { if (!string.IsNullOrEmpty(value)) { name = value; } } }
        public string FullName { get { return Name + " " + Surname; } }
        public ushort ID { get { return id; } set { id = value; } }
        public DateTime StartOfWork { get { return startOfWork; } set { startOfWork = value; } }
        public ClassSector Sector { get { return sector; } set { sector = value; } }
        public bool IndefinitePeriod { get { return indefinitePeriod; } set { indefinitePeriod = value; } }
        //public ClassSectorLeader Leader { get { return leader; } set { leader = value; } }
        public ClassSectorEmployee()
        {

        }
        public override string ToString()
        {
            return $"({ID}): " + FullName;
        }

        public override bool Equals(object obj)
        {
            return obj is ClassSectorEmployee employee &&
                   id == employee.id;
        }

        public override int GetHashCode()
        {
            return 1877310944 + id.GetHashCode();
        }
    }
}
