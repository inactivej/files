﻿using System;
using System.Windows;

namespace Project_Work
{
    /// <summary>
    /// Interaction logic for EmployeeWindow.xaml
    /// </summary>
    public partial class EmployeeWindow : Window
    {
        ClassSectorEmployee SectorEmployee;
        SectorWindow SectorWindow { get; set; } = App.Current.MainWindow as SectorWindow;
        public EmployeeWindow(ClassSectorEmployee sectorEmployee)
        {
            InitializeComponent();
            SectorEmployee = sectorEmployee;

            nameTextBox.Text = sectorEmployee.Name;
            surnameTextBox.Text =sectorEmployee.Surname;
            if(sectorEmployee.StartOfWork != null)
            {
                sofDatePicker.SelectedDate = sectorEmployee.StartOfWork;
            }
            sectorTextBlock.Text = SectorWindow.SectorNameTextBox.Text;
            inpCheckBox.IsChecked = sectorEmployee.IndefinitePeriod;
        }

        private void STORNO_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            if(string.IsNullOrEmpty(nameTextBox.Text) && string.IsNullOrEmpty(surnameTextBox.Text))
            {
                nameTextBox.Text = string.Empty;
                surnameTextBox.Text = string.Empty;
            }
            else
            {
                if(sofDatePicker.SelectedDate == null)
                {
                    MessageBox.Show("Select date", "Empty selection", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else
                {
                    SectorEmployee.Name = nameTextBox.Text;
                    SectorEmployee.Surname = surnameTextBox.Text;
                    SectorEmployee.StartOfWork = (DateTime)sofDatePicker.SelectedDate;
                    SectorEmployee.IndefinitePeriod = (bool)inpCheckBox.IsChecked;
                    DialogResult = true;
                    this.Close();
                }
            }
        }
    }
}
