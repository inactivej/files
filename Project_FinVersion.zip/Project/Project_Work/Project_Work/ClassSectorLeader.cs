﻿using System;
using System.Collections.ObjectModel;

namespace Project_Work
{
    public class ClassSectorLeader:IEmployee
    {
        string name;
        string surname;
        ushort id;
        DateTime startOfWork;
        ClassSector sector;        
        bool indefinitePeriod;
        public string Name { get { return name; } set { if (!string.IsNullOrEmpty(value)) { name = value; } } }
        public string Surname { get { return surname; } set { if (!string.IsNullOrEmpty(value)) { name = value; } } }
        public string FullName { get { return Name + " " + Surname; } }
        public ushort ID { get { return id; } set { id = value; } }
        public DateTime StartOfWork { get { return startOfWork; } set { startOfWork = value; } }
        public ClassSector Sector { get { return sector; } set { sector = value; } }
        public bool IndefinitePeriod { get { return indefinitePeriod; } set { indefinitePeriod = value; } }
        public ObservableCollection<ClassSectorEmployee> SectorEmployees { get; set; } = new ObservableCollection<ClassSectorEmployee>();
        public ClassSectorLeader()
        {
                
        }
        public override string ToString()
        {
            return $"({ID} - Leader:{Sector}): " + FullName;
        }

        public override bool Equals(object obj)
        {
            return obj is ClassSectorLeader leader &&
                   id == leader.id;
        }

        public override int GetHashCode()
        {
            return 1877310944 + id.GetHashCode();
        }
    }
}
