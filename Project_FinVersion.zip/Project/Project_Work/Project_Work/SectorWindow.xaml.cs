﻿using System.Collections.ObjectModel;
using System.Windows;

namespace Project_Work
{
    /// <summary>
    /// Interaction logic for SectorWindow.xaml
    /// </summary>
    public partial class SectorWindow : Window
    {
        ClassSector Sector { get; }              
        MainWindow MainWindow { get; set; } = App.Current.MainWindow as MainWindow;
        public ushort ec;
        public SectorWindow(ClassSector sector)
        {
            InitializeComponent();            
            this.Sector = sector;
            if (string.IsNullOrEmpty(Sector.Name))
            {
                labelValue1.Content = MainWindow.nameTxtBox.Text + " - " + "[ ]";
            }
            else
            {
                labelValue1.Content = MainWindow.nameTxtBox.Text + " - " + $"[ {Sector.Name} ]";
            }
            SectorNameTextBox.Text = sector.Name;
            ec = 0;
        }

        private void addEmp_Click(object sender, RoutedEventArgs e)
        {
            ClassSectorEmployee employee = new ClassSectorEmployee();
            EmployeeWindow window = new EmployeeWindow(employee);
            window.ShowDialog();
            if(window.DialogResult == true)
            {
                UpdateValues();
                Sector.Employees.Add(employee);                
                MessageBox.Show("Employee was add", "Notification", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        private void STORNO_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            this.Close();
        }

        private void OK_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(SectorNameTextBox.Text))
            {
                MessageBox.Show("Enter sector name please", "Empty input value", MessageBoxButton.OK, MessageBoxImage.Stop);                
            }
            else
            {
                if(SectorNameValidificator()==false)
                {
                    MessageBox.Show("Sector already exists\nCreate unique name", "Empty input value", MessageBoxButton.OK, MessageBoxImage.Stop);
                    SectorNameTextBox.Text = string.Empty;
                }
                else
                {
                    Sector.Name = SectorNameTextBox.Text;
                    if (!string.IsNullOrEmpty(ecTextBlock.Text))
                    {
                        Sector.EmployeesCount = ushort.Parse(ecTextBlock.Text);
                    }
                    DialogResult = true;
                    this.Close();                    
                }
            }
        }
        private bool SectorNameValidificator()
        {
            foreach (ClassSector sector in MainWindow.Work.Sectors)
            {
                if(sector.Name == SectorNameTextBox.Text)
                {
                    return false;
                }
            }
            return true;
        }
        public void UpdateValues()
        {
            ecTextBlock.Text = ec.ToString();
        }
    }
}
