﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Windows;

namespace Project_Work
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public List<string> fileValues;
        void FileInput_GenerateICOValues() //neefektivní, pouze zkouška
        {
            Random random = new Random();
            try
            {
                StreamWriter writer = new StreamWriter("icos.txt");
                int n;
                for (int i = 1; i <= 100; i++)
                {
                    n = random.Next(100000000, 999999999);
                    writer.WriteLine(n.ToString());
                }
                writer.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("File input error", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        List<string> FileOutput()
        {
            fileValues = new List<string>();
            try
            {
                StreamReader reader = new StreamReader("icos.txt");
                if (File.Exists("icos.txt"))
                {
                    while (!reader.EndOfStream)
                    {
                        string[] values = reader.ReadLine().Split('\n');
                        fileValues = values.ToList();
                    }
                    reader.Close();
                }
                else
                {
                    MessageBox.Show("File doesn't exist", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error reading ICO values: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return fileValues;
        }
        public ClassSector Sector { get; set; }
        public ClassWork Work { get; set; }
        public MainWindow()
        {
            FileInput_GenerateICOValues();
            FileOutput();
            Work = new ClassWork(); //!!! pozor, pokud bych nevytvořil instatnci pro ClassWork, vyhodí mi to chybu: "NullReferenceException"
            InitializeComponent();          
            /*Komponenty*/
            labelValue1.Visibility = Visibility.Hidden;
            sectorsListBox.Visibility = Visibility.Hidden;
            suppliersListBox.Visibility = Visibility.Hidden;
            removeSECBTN.Visibility = Visibility.Hidden;
            removeSUPBTN.Visibility = Visibility.Hidden;           
            sectorsListBox.ItemsSource = Work.Sectors;
            suppliersListBox.ItemsSource = Work.Suppliers;            
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(nameTxtBox.Text))
            {
                MessageBox.Show("Work need name to be created", "Empty input warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                nameTxtBox.Text = string.Empty;
            }
            else
            {
                ClassWork work = new ClassWork //novinka!!!
                {
                    Name = nameTxtBox.Text,
                    ICO = icoTextBlock.Text,
                };
                labelValue1.Visibility = Visibility.Visible;
                labelValue1.Content = $"Sectors of {work.Name}";
                sectorsListBox.Visibility = Visibility.Visible;
                removeSECBTN.Visibility = Visibility.Visible;
            }
        }

        private void newSector_Click(object sender, RoutedEventArgs e)
        {
            Sector = new ClassSector();           
            SectorWindow window = new SectorWindow(Sector);
            window.ShowDialog();
            if (window.DialogResult == true)
            {
                Work.Sectors.Add(Sector);
            }
        }
        void ICOValues(List<string> fileValues)
        {
            if (fileValues != null)
            {
                Random randIco = new Random();
                int index = randIco.Next(fileValues.Count);
                icoTextBlock.Text = fileValues[index];
            }
            else
            {
                MessageBox.Show("ICO values are not available.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void nameTxtBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            ICOValues(fileValues); //dořešit nefunkčnost
        }
    }
}
