﻿using System.Collections.ObjectModel;

namespace Project
{
    public class ClassShop
    {
        public ObservableCollection<ClassSale> Sales { get; set; } = new ObservableCollection<ClassSale>();
        public ObservableCollection<ClassShopPart> ShopParts { get; set; } = new ObservableCollection<ClassShopPart>();
        string name;
        public string Name { get { return name; } set { if (!string.IsNullOrEmpty(value)) { name = value; } } }        
        public ClassShop()
        {

        }
        public override string ToString()
        {
            return Name;
        }
    }
}
