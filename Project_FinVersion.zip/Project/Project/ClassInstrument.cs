﻿namespace Project
{
    public class ClassInstrument:IProduct
    {
        string name;
        ulong price; 
        bool stringTypeInstument;       
        public string Name { get { return name; } set { if (!string.IsNullOrEmpty(value)) { name = value; } } }
        public ulong Price { get { return price; } set { if (value >= 0) { price = value; } } }
        public bool StringTypeInstrument { get { return stringTypeInstument; } set { stringTypeInstument = value; } }
        public ClassInstrument()
        {
            
        }
        public override string ToString()
        {
            if (StringTypeInstrument)
            {
                return $"{Name}\t({Price} Kč;String: Yes)";
            }
            else
            {
                return $"{Name}\t({Price} Kč;String: No)";
            }
        }
    }
}
