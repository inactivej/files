﻿ using System;

namespace Project
{
    public interface IPerson
    {
        string Name { get; set; }
        string Surname { get; set; }
        string Fullname { get; }        
        DateTime DOB { get; set; }
    }
}
