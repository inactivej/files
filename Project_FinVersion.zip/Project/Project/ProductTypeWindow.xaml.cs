﻿using System.Windows;

namespace Project
{
    public partial class ProductTypeWindow : Window
    {
        private static ProductTypeWindow instance;
        public IProduct SelectedProduct { get; set; }

        public ProductTypeWindow()
        {
            InitializeComponent();
            instance = this;
        }

        public static ProductTypeWindow getInstance() { return instance; }

        private void MPCB_Checked(object sender, RoutedEventArgs e)
        {
            SelectedProduct = new ClassMusicProject();
            this.DialogResult = true;
            this.Close();
        }

        private void exitCB_Checked(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void INSTRCB_Checked(object sender, RoutedEventArgs e)
        {
            SelectedProduct = new ClassInstrument();
            this.DialogResult = true;
            this.Close();
        }

        private void newMusicianRB_Checked(object sender, RoutedEventArgs e)
        {
            ClassMusician musician = new ClassMusician();
            MusicianWindow window = new MusicianWindow(musician);
            window.ShowDialog();
            if (window.DialogResult == true)
            {
                ShopPartWindow.getInstance().Musicians.Add(musician);
                ShopPartWindow.getInstance().FileInput();
                this.Close();
            }            
        }
    }
}

