﻿using System;
using System.Collections.ObjectModel;

namespace Project
{
    public class ClassMusicProject : IProduct
    {        
        string name;
        ulong price;        
        DateTime releasedate;
        public string Name { get { return name; } set { if (!string.IsNullOrEmpty(value)) { name = value; } } }
        public ulong Price { get { return price; } set { if (value >= 0) { price = value; } } }
        public ClassMusician Songwriter { get; set; }
        public DateTime ReleaseDate { get { return releasedate; } set { if (value != null) { releasedate = value; } } }
        public ClassMusicProject()
        {
            
        }
        public override string ToString()
        {
            return Name + "\t" + $"Price:{Price}Kč";
        }
    }
}
