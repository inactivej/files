﻿using System;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;

namespace Project
{
    /// <summary>
    /// Interaction logic for EmployeeWindow.xaml
    /// </summary>
    public partial class EmployeeWindow : Window
    {
        ClassEmployee employee;
        //ClassEmployee employee_copy = new ClassEmployee();
        public EmployeeWindow(ClassEmployee employee)
        {
            InitializeComponent();            
            if (employee != null)
            {
                this.employee = employee;
                DataContext = this.employee;
                E_NameTextBox.Text = employee.Name;
                E_SurnameTextBox.Text = employee.Surname;
                typeComboBox.SelectedItem = (bool)employee.FullTime;
                dobDatePicker.SelectedDate = employee.DOB;
            }            
        }
        private void okBTN_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(E_NameTextBox.Text) || string.IsNullOrEmpty(E_SurnameTextBox.Text))
            {
                MessageBox.Show("Enter Full name of employee", "Invalid input", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            else
            {

                if (dobDatePicker.SelectedDate == null || dobDatePicker.SelectedDate > DateTime.Now)
                {
                    MessageBox.Show("Select valid date", "Invalid date", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else if (!DOBVerify())
                {
                    MessageBox.Show("Person isn't 18 or above", "Invalid date", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else
                {
                    if (typeComboBox.SelectedItem == null)
                    {
                        MessageBox.Show("Select employee's work type", "Empty selection", MessageBoxButton.OK, MessageBoxImage.Stop);
                    }                     
                    else
                    {
                        employee.ID = employee.getID();
                        employee.Name = E_NameTextBox.Text;
                        employee.Surname = E_SurnameTextBox.Text;
                        if (string.Equals((typeComboBox.SelectedItem as ComboBoxItem)?.Content.ToString(), "Full-time", StringComparison.OrdinalIgnoreCase))
                        {
                            employee.FullTime = true;
                        }
                        else
                        {
                            employee.FullTime = false;
                        }
                        DialogResult = true;
                    }
                }
            }
        }
        private void stornoBTN_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        bool DOBVerify()
        {                    
            TimeSpan difference = DateTime.Now - (DateTime)dobDatePicker.SelectedDate;  //(TimeSpan = časový interval)     
            int ageInYears = (int)(difference.TotalDays / 365.25);            
            if (ageInYears >= 18)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
