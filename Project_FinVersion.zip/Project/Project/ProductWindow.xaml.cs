﻿using System;
using System.Windows;

namespace Project
{
    /// <summary>
    /// Interaction logic for ProductWindow.xaml
    /// </summary>
    public partial class ProductWindow : Window
    {
        IProduct product = ProductTypeWindow.getInstance().SelectedProduct;
        public ProductWindow(IProduct product)
        {
            InitializeComponent();            
            if(product != null)
            {
                this.product = product;
                NameTextBox.Text = product.Name;
                priceTxtBox.Text = product.Price.ToString();
                if (product is ClassMusicProject mp)
                {
                    DisplayComponents_MusicProject();
                    songWriterComboBox.SelectedItem = mp.Songwriter;
                    datePickerDOR.SelectedDate = mp.ReleaseDate;                    
                    
                }
                else if (product is ClassInstrument instrument)
                {
                    DisplayComponents_Instrumental();
                    checkbox_StringInstro.IsChecked = (bool)instrument.StringTypeInstrument;
                }
            }
        }
        void DisplayComponents_MusicProject()
        {
            checkbox_StringInstro.Visibility = Visibility.Hidden;

            datePickerDOR.Visibility = Visibility.Visible;
            label_DOR.Visibility = Visibility.Visible;
            label_DOR.Content = "DOR";
            label_songWriter.Visibility = Visibility.Visible;
            label_songWriter.Content = "Singer";
            songWriterComboBox.Visibility = Visibility.Visible;
            songWriterComboBox.ItemsSource = ShopPartWindow.getInstance().Musicians;
        }

        void DisplayComponents_Instrumental()
        {
            songWriterComboBox.Visibility = Visibility.Hidden;
            label_songWriter.Visibility = Visibility.Hidden;
            datePickerDOR.Visibility = Visibility.Hidden;

            checkbox_StringInstro.Visibility = Visibility.Visible;
            checkbox_StringInstro.Content = "String instrument";
        }

        private void okBTN_Click_1(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(NameTextBox.Text))
            {
                MessageBox.Show("Enter Full name of project", "Invalid input", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            else
            {
                ulong price;
                if (!ulong.TryParse(priceTxtBox.Text, out price))
                {
                    MessageBox.Show("Enter valid price", "Invalid input", MessageBoxButton.OK, MessageBoxImage.Stop);
                    priceTxtBox.Text = string.Empty;
                }
                else
                {
                    product.Name = NameTextBox.Text;
                    product.Price = ulong.Parse(priceTxtBox.Text);
                    if (product is ClassMusicProject)
                    {
                        if (datePickerDOR.SelectedDate == null)
                        {
                            MessageBox.Show("Select date of release", "Empty selection", MessageBoxButton.OK, MessageBoxImage.Stop);
                        }
                        else if(datePickerDOR.SelectedDate > DateTime.Now)
                        {
                            MessageBox.Show($"Date of release cannot be greater than today's date:{DateTime.Now.ToString("d")}", "Invalid date", MessageBoxButton.OK, MessageBoxImage.Stop);
                        }
                        else
                        {
                            if (songWriterComboBox.SelectedItem == null)
                            {
                                MessageBox.Show("Select musician", "Empty selection", MessageBoxButton.OK, MessageBoxImage.Stop);
                            }
                            else
                            {
                                ClassMusicProject mp = (ClassMusicProject)product;
                                mp.ReleaseDate = (DateTime)datePickerDOR.SelectedDate;
                                mp.Songwriter = (ClassMusician)songWriterComboBox.SelectedItem;
                                DialogResult = true;
                                this.Close();
                            }
                        }
                    }
                    else if (product is ClassInstrument)
                    {
                        ClassInstrument instrument = (ClassInstrument)product;
                        instrument.StringTypeInstrument = (bool)checkbox_StringInstro.IsChecked;
                        DialogResult = true;
                        this.Close();
                    }
                }                
            }
        }
        private void stornoBTN_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

    }
}


