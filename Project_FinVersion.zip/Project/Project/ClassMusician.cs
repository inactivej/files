﻿using System;

namespace Project
{
    public class ClassMusician : IPerson
    {
        string name;
        string surname;
        DateTime dob;
        string stageName;
        public string Name { get { return name; } set { if (!string.IsNullOrEmpty(value)) { name = value; } } }
        public string Surname { get { return surname; } set { if (!string.IsNullOrEmpty(value)) { surname = value; } } }
        public string Fullname { get { return Name + " " + Surname; } }
        public string StageName { get { return stageName; } set { if (!string.IsNullOrEmpty(value)) { stageName = value; } } }
        public DateTime DOB { get { return dob; } set { dob = value; } }
        public ClassMusician(string name, string surname, string stageName,DateTime dob)
        {
            Name = name;
            Surname = surname;
            StageName = stageName;          
            DOB = dob;
        }
        public ClassMusician()
        {
            
        }
        public override string ToString()
        {
            return $"{StageName}";
        }
    }
}
