﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Documents;

namespace Project
{
    /// <summary>
    /// Interaction logic for ShopPartWindow.xaml
    /// </summary>
    public partial class ShopPartWindow : Window
    {
        static ShopPartWindow instance;
        ushort instrumentsCount = 0;
        ushort mpCount = 0;        
        MainWindow MainWindow { get; set; } = App.Current.MainWindow as MainWindow;
        public void FileOutput()
        {
            StreamReader reader = new StreamReader("musicians.txt");
            while (!reader.EndOfStream)
            {
                string line = reader.ReadLine();
                string[] values = line.Split(';');
                Musicians.Add(new ClassMusician(values[0], values[1], values[2], DateTime.Parse(values[3])));
            }
            reader.Close();
        }
        public void FileInput()
        {
            StreamWriter writer = new StreamWriter("musicians.txt");
            foreach (ClassMusician musician in Musicians)
            {
                writer.WriteLine(musician.Name + ";" + musician.Surname + ";" + musician.StageName + ";" + musician.DOB.ToString("d"));
            }
            writer.Close();
        }
        void Stats_ShopPart()
        {
            StocksCount_TxtBlock.Text = Stock.Count.ToString();
            StocksInstrumentsCount_TxtBlock.Text = instrumentsCount.ToString();
            StocksMPCount_TxtBlock.Text = mpCount.ToString();
            if(Employees.Count() == 0)
            {
                EmployeesCount_TxtBlock.Text = "0";
            }
            else
            {
                EmployeesCount_TxtBlock.Text = shopPart.EmployeeCount.ToString();                
            }            
        }

        ClassShopPart shopPart;

        public ObservableCollection<ClassMusician> Musicians { get; set; } = new ObservableCollection<ClassMusician>();
        public ObservableCollection<ClassEmployee> Employees { get; set; } = new ObservableCollection<ClassEmployee>();
        public ObservableCollection<IProduct> Stock { get; set; } = new ObservableCollection<IProduct>();
        string partname = string.Empty;
        /*--------------------------------------------------------------------------------------------------------------*/
        public ShopPartWindow(ClassShopPart shopPart)
        {
            InitializeComponent();
            FileOutput();
            if (shopPart != null)
            {
                Stats_ShopPart();
                partNameTextBox.Text = shopPart.PartName;
                shopPart_ItemsStock.Visibility = Visibility.Hidden;
                shopPartEmployeesListBox.Visibility = Visibility.Hidden;
                removeButton.Visibility = Visibility.Hidden;
                this.shopPart = shopPart;
                DataContext = this.shopPart;
                Employees = shopPart.Employees;
                Stock = shopPart.Stock;
                ShopPartInfoLabel.Content = MainWindow.shopTextBox.Text + "-" + partNameTextBox.Text;
                if (Employees.Count != 0)
                {
                    leaderComboBox.SelectedItem = shopPart.Leader.ToString();
                }
            }
            instance = this;
        }
        public static ShopPartWindow getInstance() { return instance; }
        private void newEmployeeItem_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Add new employee?", "Employee menu", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                ClassEmployee employee = new ClassEmployee();
                EmployeeWindow window = new EmployeeWindow(employee);
                window.ShowDialog();
                if (window.DialogResult == true)
                {
                    shopPart.EmployeeCount++;
                    Employees.Add(employee);
                    Stats_ShopPart();
                }
            }
        }
        private void okBTN_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(partNameTextBox.Text))
            {
                MessageBox.Show("Enter part name", "Invalid input", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
            else
            {
                if (shopPart.EmployeeCount == 0)
                {
                    MessageBox.Show($"Shop part must have a leader\nActual count of employees is {shopPart.EmployeeCount} (Please add employes to able to finish)", "Attention", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else if (leaderComboBox.SelectedItem == null)
                {
                    MessageBox.Show($"Shop part must have a leader\nActual count of employees is {shopPart.EmployeeCount} (Select one from list of employees)", "Empty selection", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else if (leaderComboBox.SelectedItem.ToString().Contains("(P)"))
                {
                    MessageBox.Show($"Shop leader must work Full Time {"(F)"}", "Attention", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else
                {
                    shopPart.PartName = partNameTextBox.Text;
                    shopPart.Leader = (ClassEmployee)leaderComboBox.SelectedItem;
                    foreach (ClassEmployee employee in Employees)
                    {
                        if (employee == shopPart.Leader)
                        {
                            employee.IsLeader = true;
                        }
                    }
                    DialogResult = true;
                    this.Close();
                }
            }
        }
        private void showEmployeesCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            shopPartEmployeesListBox.Visibility = Visibility.Visible;
            removeButton.Visibility = Visibility.Visible;
        }

        private void showStockCheckBox_Checked(object sender, RoutedEventArgs e)
        {
            shopPart_ItemsStock.Visibility = Visibility.Visible;
            removeButton.Visibility = Visibility.Visible;
        }

        private void showEmployeesCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            shopPartEmployeesListBox.Visibility = Visibility.Hidden;
            if (showStockCheckBox.IsChecked == false)
            {
                removeButton.Visibility = Visibility.Hidden;
            }
        }

        private void showStockCheckBox_Unchecked(object sender, RoutedEventArgs e)
        {
            shopPart_ItemsStock.Visibility = Visibility.Hidden;
            if (showEmployeesCheckBox.IsChecked == false)
            {
                removeButton.Visibility = Visibility.Hidden;
            }
        }
        private void newItem_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show("Add new product?", "Stock", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                ProductTypeWindow productTypeWindow = new ProductTypeWindow();
                productTypeWindow.ShowDialog();
                if (productTypeWindow.DialogResult == true)
                {
                    ProductWindow productWindow = new ProductWindow(productTypeWindow.SelectedProduct);
                    productWindow.ShowDialog();
                    if (productWindow.DialogResult == true)
                    {
                        shopPart.Stock.Add(productTypeWindow.SelectedProduct);
                        if (productTypeWindow.SelectedProduct is ClassMusicProject)
                        {
                            mpCount++;
                        }
                        else if (productTypeWindow.SelectedProduct is ClassInstrument)
                        {
                            instrumentsCount++;
                        }
                        Stats_ShopPart();
                    }
                }
            }
        }
        private void removeButton_Click_1(object sender, RoutedEventArgs e)
        {
            if (shopPartEmployeesListBox.SelectedItems != null)
            {
                List<ClassEmployee> values = new List<ClassEmployee>();
                foreach (ClassEmployee item in shopPartEmployeesListBox.SelectedItems)
                {
                    values.Add(item);
                }
                foreach (ClassEmployee item in values)
                {
                    Employees.Remove(item);
                }
            }
            if (shopPart_ItemsStock.SelectedItems != null)
            {
                List<IProduct> values = new List<IProduct>();
                foreach (IProduct item in shopPart_ItemsStock.SelectedItems)
                {
                    values.Add(item);
                }
                foreach (IProduct item in values)
                {
                    Stock.Remove(item);
                    if(item is ClassMusicProject)
                    {
                        mpCount--;
                    }
                    else if(item is ClassInstrument)
                    {
                        instrumentsCount--;
                    }
                }
                Stats_ShopPart();
            }
        }

        private void shopPart_ItemsStock_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            IProduct sp = shopPart_ItemsStock.SelectedItem as IProduct;
            ProductWindow window = new ProductWindow(sp);
            window.ShowDialog();
            shopPart_ItemsStock.Items.Refresh();
        }

        private void shopPartEmployeesListBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            ClassEmployee se = shopPartEmployeesListBox.SelectedItem as ClassEmployee;
            EmployeeWindow window = new EmployeeWindow(se);
            window.ShowDialog();
            shopPartEmployeesListBox.Items.Refresh();
        }
    }
}
