﻿using System.Collections.ObjectModel;

namespace Project
{
    public class ClassShopPart
    {
        string partName;
        ushort employeeCount;
        ClassEmployee leader;

        public ObservableCollection<ClassEmployee> Employees { get; set; } = new ObservableCollection<ClassEmployee>(); 
        public ObservableCollection<IProduct> Stock { get; set; } = new ObservableCollection<IProduct>(); 
               
        public string PartName { get { return partName; } set { if (!string.IsNullOrEmpty(value)) { partName = value; } } }
        public ushort EmployeeCount { get { return employeeCount; } set { if (value >= 0) { employeeCount = value; } } }       

        public ClassEmployee Leader { get; set; }
        public ClassShopPart()
        {

        }
        public override string ToString()
        {
            return PartName + $"({Leader})";
        }

    }
}
