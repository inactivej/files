﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace Project
{
    /// <summary>
    /// Interaction logic for MusicianWindow.xaml
    /// </summary>
    public partial class MusicianWindow : Window
    {
        ClassMusician musician;
        public MusicianWindow(ClassMusician musician)
        {
            InitializeComponent();
            this.musician = musician;
            if(musician != null)
            {
                NameTextBox.Text = musician.Name;
                SurnameTextBox.Text = musician.Surname;
                stageNameTextBox.Text = musician.StageName;
                dobDatePicker.SelectedDate = musician.DOB;
            }
        }
        private void okBTN_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(NameTextBox.Text) || string.IsNullOrEmpty(SurnameTextBox.Text))
            {
                MessageBox.Show("Enter Full name of musician", "Invalid input", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            else
            {
                if (string.IsNullOrEmpty(stageNameTextBox.Text))
                {
                    MessageBox.Show("Enter stage name of musician", "Invalid input", MessageBoxButton.OK, MessageBoxImage.Stop);
                }
                else
                {
                    if (dobDatePicker.SelectedDate == null || dobDatePicker.SelectedDate > DateTime.Now)
                    {
                        MessageBox.Show("Select valid date", "Invalid date", MessageBoxButton.OK, MessageBoxImage.Stop);
                    }
                    else
                    {
                        musician.Name = NameTextBox.Text;
                        musician.Surname = SurnameTextBox.Text;
                        musician.StageName = stageNameTextBox.Text;
                        musician.DOB = (DateTime)dobDatePicker.SelectedDate;
                        DialogResult = true;
                        this.Close();
                    }
                }
            }
        }

        private void stornoBTN_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
        }
    }
}
