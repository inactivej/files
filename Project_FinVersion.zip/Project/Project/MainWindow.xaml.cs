﻿using Microsoft.Win32;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Windows;

namespace Project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private static ulong sum = 0;
        ClassShop Shop { get; set; }
        public ObservableCollection<ClassShopPart> ShopParts { get; set; } = new ObservableCollection<ClassShopPart>();
        public ObservableCollection<ClassSale> Sales { get; set; } = new ObservableCollection<ClassSale>();
        public MainWindow()
        {
            InitializeComponent();
            if (ShopParts.Count != 0)
            {
                ShopParts = Shop.ShopParts;
                Sales = Shop.Sales;
            }
            shopPartsListBox.Visibility = Visibility.Hidden;
            removeShopPartButton.Visibility = Visibility.Hidden;
            frameSales.Visibility = Visibility.Hidden;
            labelSales.Visibility = Visibility.Hidden;
            SalesListBox.Visibility = Visibility.Hidden;
            productForSaleComboBox.Visibility = Visibility.Hidden;
            removeSaleButton.Visibility = Visibility.Hidden;
            productLabel.Visibility = Visibility.Hidden;

            DataContext = this;
        }
        private void createShopButton_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(shopTextBox.Text))
            {
                MessageBox.Show("Shop name is necessary for creating new one\nPlease enter name!", "Empty input value for Shop", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
            else
            {
                Shop = new ClassShop();
                shopPartsListBox.Visibility = Visibility.Visible;
                removeShopPartButton.Visibility = Visibility.Visible;
                frameSales.Visibility = Visibility.Visible;
                labelSales.Visibility = Visibility.Visible;
                SalesListBox.Visibility = Visibility.Visible;
                productForSaleComboBox.Visibility = Visibility.Visible;
                removeSaleButton.Visibility = Visibility.Visible;
                productLabel.Visibility = Visibility.Visible;

                MessageBox.Show("Shop was created!", "Information", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }
        private void newShopPartItem_Click(object sender, RoutedEventArgs e)
        {
            ClassShopPart shopPart = new ClassShopPart();
            ShopPartWindow window = new ShopPartWindow(shopPart);
            window.ShowDialog();
            if (window.DialogResult == true)
            {
                ShopParts.Add(shopPart);
                if (shopPart.Stock.Count != 0)
                {
                    productForSaleComboBox.ItemsSource = shopPart.Stock;
                }
            }
        }

        private void shopPartsListBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            ClassShopPart selectedItem = shopPartsListBox.SelectedItem as ClassShopPart;
            ShopPartWindow window = new ShopPartWindow(selectedItem);
            window.ShowDialog();
            shopPartsListBox.Items.Refresh();
        }

        private void saleProductItem_Click(object sender, RoutedEventArgs e)
        {
            if (productForSaleComboBox.SelectedItem != null)
            {
                if (productForSaleComboBox.SelectedItem is IProduct selectedProduct)
                {
                    ClassSale sale = new ClassSale();
                    sale.Product = selectedProduct;
                    Sales.Add(sale);
                }
            }
            else
            {
                MessageBox.Show($"Select product for sale", "Empty selection", MessageBoxButton.OK, MessageBoxImage.Stop);
            }
        }

        private void exitItem_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void saveItem_Ser_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog fileDialog = new SaveFileDialog();
            if (fileDialog.ShowDialog() == true)
            {
                try
                {
                    var list = ShopParts.ToList();
                    var list2 = Sales.ToList();
                    //1. serializuje objekty, které deklaruje jako "collection" (typ objektu se kterým json pracuje)
                    var json = JsonConvert.SerializeObject(new { Collection1 = list, Collection2 = list2 });
                    File.WriteAllText(fileDialog.FileName, json);
                    MessageBox.Show("Data has been successfully saved.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"A problem occurred while saving data: {ex.Message}");
                }
            }
        }

        private void loadItem_Des_Click(object sender, RoutedEventArgs e)
        {
            //NEFUNGUJE A NEVÍM SI RADY JAK A CO DĚLAT
            //PROBLÉM:
            /*A problem occurred while loading data: Could not create an instance of,
            type Project.IProduct. Type is an interface or abstract class and cannot
            be instantiated, Path "Collection1[0}.Stack(0).ID.*/

            OpenFileDialog fileDialog = new OpenFileDialog();
            if (fileDialog.ShowDialog() == true)
            {
                try
                {
                    string json = File.ReadAllText(fileDialog.FileName);
                    //1. deserializuje json do dynamického objektu (dynamic = kompilátor nebude kontrolovat typy objektů!)
                    var data = JsonConvert.DeserializeObject<dynamic>(json);
                    //2. Přetypuje objekty (collection) na json pole a potom objekty převede na daný datový typ (v mém případě to jsou knihovny ShopPart a Sale)
                    var list1 = ((JArray)data.Collection1).ToObject<List<ClassShopPart>>();
                    var list2 = ((JArray)data.Collection2).ToObject<List<ClassSale>>();
                    ShopParts.Clear();
                    foreach (var item in list1)
                    {
                        ShopParts.Add(item);
                    }
                    Sales.Clear();
                    foreach (var item in list2)
                    {
                        Sales.Add(item);
                    }
                    MessageBox.Show("Data has been successfully loaded.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"A problem occurred while loading data: {ex.Message}");
                }
            }
        }

        private void removeSaleButton_Click(object sender, RoutedEventArgs e)
        {
            if (SalesListBox.SelectedItems != null)
            {
                List<ClassSale> sales = new List<ClassSale>();
                foreach (ClassSale item in SalesListBox.SelectedItems)
                {
                    sales.Add(item);
                }
                foreach (ClassSale item in sales)
                {
                    Sales.Remove(item);
                }
            }
            else
            {
                MessageBox.Show("Select sale", "Empty selection", MessageBoxButton.OK, MessageBoxImage.Stop);

            }
        }
        private void removeShopPartButton_Click(object sender, RoutedEventArgs e)
        {
            if (shopPartsListBox.SelectedItems != null)
            {
                List<ClassShopPart> parts = new List<ClassShopPart>();
                foreach (ClassShopPart item in shopPartsListBox.SelectedItems)
                {
                    parts.Add(item);
                }
                foreach (ClassShopPart item in parts)
                {
                    ShopParts.Remove(item);
                }
            }
            else
            {
                MessageBox.Show("Select shop part", "Empty selection", MessageBoxButton.OK, MessageBoxImage.Stop);

            }
        }

        private void showStas_Item_Click(object sender, RoutedEventArgs e)
        {
            if (Shop != null)
            {
                if (ShopPartWindow.getInstance() != null && ShopParts.Count != 0)
                {
                    MessageBox.Show($"---------------\nShop parts:{ShopParts.Count}\nEmployees:{ShopPartWindow.getInstance().Employees.Count}\nBank:{BANK_SUM(sum)} Kč", $"Statistics about shop {Shop.Name}");
                }
                else
                {
                    MessageBox.Show("No data found", "Warning", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            else
            {
                MessageBox.Show("No data found", "Warning", MessageBoxButton.OK, MessageBoxImage.Error);

            }
        }
        ulong BANK_SUM(ulong sum)
        {
            foreach (IProduct product in ShopPartWindow.getInstance().Stock)
            {
                sum += product.Price;
            }
            return sum;
        }
    }
}
