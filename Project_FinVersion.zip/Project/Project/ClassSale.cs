﻿using System.Windows;

namespace Project
{
    public class ClassSale
    {
        ushort id;
        private static ushort count = 0;
        public ushort ID { get { return id; } set { if (value >= 0) { id = value; } } }
        public IProduct Product { get; set; }
        public ClassSale()
        {
            this.ID = ++count;
        }
        public ushort getID()
        {
            return ID;
        }
        public override string ToString()
        {
            return ID + "\t" + Product.Name + " " + Product.Price +" Kč";
        }
    }
}
