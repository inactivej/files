﻿namespace Project
{
    public interface IProduct
    {
        string Name { get; set; }
        ulong Price { get; set; }
    }
}
